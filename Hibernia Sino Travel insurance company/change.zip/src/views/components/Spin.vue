<template>
  <div class="animated fadeIn">

          <Row>
        <Col span="24" >
           
           <div  class="doc-header">

    <Spin size="small" style="display:inline-block"></Spin>
    <Spin style="display:inline-block"></Spin>
    <Spin size="large" style="display:inline-block"></Spin>

            </div>
            <div style="" class="doc-content">
                <h5>各种尺寸</h5>
  
        <p>通过设置size属性为large和small将 Spin 设置为大和小尺寸，不设置为默认（中）尺寸。</p>
            </div>
             
        </Col>

    </Row> 





</div>
</template>

<script>

export default {
  name: 'spin',

}


</script>



<style type="text/css">


</style>