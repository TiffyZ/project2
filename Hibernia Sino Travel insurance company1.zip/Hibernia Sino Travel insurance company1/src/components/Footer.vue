<template>
  <footer class="app-footer">
    <a >WZ</a> &copy; 2017 creativeLabs.
    <span class="float-right">Powered by <a href="http://coreui.io">Hibernia Sino Travel insurance company</a></span>
  </footer>
</template>
<script>
export default {
  name: 'footer'
}
</script>
